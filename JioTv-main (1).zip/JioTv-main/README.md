
<p align='center'><img src="https://i.ibb.co/BcjC6R8/jiotv.png" width="120" ></p>



<h4 align='center'>📺 The PHP Script For Grab Streaming Links and Play it ,</br> This  Works Mobile,Tizen OS ,Web Os, AndroidTV , PC Browser Perfect

Through LocalHost </br></br>🌟 Star This Repository Before Forking 😎</br>Don't Edit This Script



<h2>🍁 HOW TO USE : </h2>

### 🔐 Installation :

### 🅰️ First Download This Application ( PHP WEB SERVER )

1. `KSWEB PRO v3.987 for Mobile`

```

https://tsneh.vercel.app/ksweb_3.987.apk

```

2. `XAMPP for Windows (PC)`

```

https://www.apachefriends.org/download.html

```

### 🅱️ Then Download This Zip File

- [JioTV Zip](https://github.com/Jitendraunatti/JioTv/archive/refs/heads/main.zip) </br>

1. Locate and delete `index.php` if this is your first-time setup, then extract all files into the `htdocs` root folder in localhost. </br> 

2. Open KSWEB app & start the server. </br>

3. Now Open `JioTV` Below Link :

```

http://localhost:8080/JioTv/

```

4. First Login with your credentials.

5. Now, You Will See all Jio Channels. </br>

6. Click on Channel and Play. </br>


</br>

<h3>👿 LOGIN :</h3>

1. Open `JioTV`  </br>

2. Click on the Login button. </br>
3. Enter your **Jio mobile number**. </br>
3. Enter **Otp.** </br>
<img src="https://i.ibb.co/WtP1TgY/iage.png" alt="home" width="700" height="350">

<h3>♻️ JOIN FOR UPDATES :</h3>

- JOIN OUR TELEGRAM CHANNEL

- https://t.me/jitendraunatti_github

<h3>😇 SCRIPT FEATURES :</h3>

- Star Added ["Star Tv"];
- New UI & Design

- OTP Login Added

- Dropdown Filters Updated

- Multi Audio Stream Support

- Web Play with Quality Change Supports

-  Works on **Mobile,Tizen OS ,Web Os, AndroidTV , PC Browser Perfect**

<h3>☠️ ADVANCED  FEATURES :</h3>

- The channels and playlist are fetched directly from the JioTV API.





<h3>TIZEN OS ,WEB OS  ANDRIOD TV SETUP:</h3>


-   **Install KS Web App**:
    
    -   Ensure that the **KS Web** app is installed on your mobile device.
-   **Connect Devices**:
    
    -   Your mobile device and TV must be connected to the **same Wi-Fi network**.
-   **Accessing on TV**:
    
    -   Open the web browser on your TV.
    -   On your mobile device, you will be provided with an IP address by the KS Web app.
    -   **Note**: This IP address is different for every user.
    -   Enter the provided IP address into your TV's browser .Ex http://192.168.0.120:8080
-   **Example**:
<img src="https://i.ibb.co/K5s5n5d/IMG-20240811-170717.jpg" alt="mob-Catchup" width="320">



<h3>💖 PLAYER FEATURES :</h3>

- Search Feature Added</br>

1. 🔍 SEARCH BY CHANNEL NAME

```

e.g. Sony,Zee,Star ...

```

2. 🔍 SEARCH BY GENRE

```

e.g. Entertainment,Kids,Movies,Music ...

```

3. 🔍 SEARCH BY LANGUAGE

```

e.g. Hindi,Tamil,Kannada,Odia ...

```



</br>

<h3>📸 MOBILE SHOTS : </h3>

<p align="left">

<img src="https://i.ibb.co/FJyHxGq/Screenshot-2024-06-12-08-10-02-223-com-android-chrome.jpg" alt="mob-home" width="120">

<img src="https://i.ibb.co/SKnJgPy/Screenshot-2024-06-12-08-10-41-953-com-android-chrome.jpg" alt="mob-7-Days" width="120">

</p>

<p align="left">



</p>

<h3>📸 PC WEB SHOTS : </h3>


<img src="https://i.ibb.co/NZLZsR0/imge.png" alt="home" width="300" height="150"></br>




<img src="https://i.ibb.co/fxb1wr1/image.png" width="300" height="150"></br>


</br>

<h3>☠️ Video </h3>
<img src="https://i.ibb.co/gW54cZ2/image.png" width="300" height="150"></br>

- If you see this video, that means the channel is currently not working or the script is outdated.

<img src="https://i.ibb.co/zsxf29p/image.png" width="300" height="150"></br>

- If you see this type of image on the index.php or JioTV site, that means you need to update your script from my  github account .

</br>


</br>


## ▶️ PlayList Methods :

• In Tivimate or OTT Navigator Player Put Links Format Like Below :

```

http://localhost:8080/JioTv/playlist.php

```

• Hurrah !! Now Play & Enjoy with your Jio Channels .

<h3>🚸 WARNINGS :</h3>

- This is Just For Educational Purpose
- I am in no way responsible if you misuse the code and cause revenue loss to the concerned parties and owners of the portal
- Don't Sell this Script, This is 💯% Free
<hr>

<h3>🤗 CONTACT US : </h3>

- TELEGRAM CHANNEL  JOIN NOW https://t.me/jitendraunatti_github
- FOR ANY QUERY CONTACT US ON [PROTON-MAIL](mailto:jitendraunatti@pm.me)

</br>
<hr>

<h3> ⚠️License and Disclosures : </hr>

This code is just a CASE STUDY on how the authentication mechanism and live streaming using IPTV works I am in no way responsible if you misuse the code and cause revenue loss to the concerned parties and owners of the portal
This code is protected under the [GPL](https://github.com/Jitendraunatti/JioTv/blob/main/LICENSE) license


<h4 align='center'>© 2021-24 JITENDRA KUMAR</h4>

<!-- DO NOT REMOVE THIS CREDIT -->
<!-- © 2021-24 jitendra kumar -->
